# United Hearts(We Are One)--Donation-Website
About Us
United Hearts is a charitable food delivery project that focuses on providing nutritious meals to those in need while promoting sustainability through upcycling.

Our Services
We collaborate with local restaurants and collages to rescue surplus food, which would otherwise go to waste, and distribute it to communities facing food insecurity. UNITED HEARTS represents a harmonious convergence of empathy, innovation, and collective action, poised to make a meaningful impact on society. Additionally, we offer upcycled products made from recycled materials.